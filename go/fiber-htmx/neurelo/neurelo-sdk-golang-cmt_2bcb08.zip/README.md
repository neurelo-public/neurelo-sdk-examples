# Neurelo Go SDK

Neurelo's Go SDK allows you to quickly and easily integrate your app with Neurelo APIs. This SDK is generated from the API spec and provides a set of methods to interact with the API endpoints.

Please refer to all the available examples here: [Neurelo SDK Examples 🔗](https://github.com/neurelo-public/neurelo-sdk-examples)

- These examples are built to act as a starter template for your project
- You can use these examples to understand how to use the SDK in your project

This generator creates a Go client that utilizes the std package `net/http` to make HTTP requests.
Tested with GO v1.22.3

## Prerequisites:

- GO binaries are installed on your system and included in your path.
- Download your generated SDK from the API page of your project & move the generated SDK file `neurelo-sdk-golang-cmt_<id>.zip` to your project root.
- Tools for configuring environment variables (e.g. [github.com/joho/godotenv](https://github.com/joho/godotenv)) or simply export before starting your dev server (inline).

## Installation:

- Copy the generated sdk `neurelo-sdk-golang-cmt_<>.zip` to your project
- Unzip the sdk to `<project_root>/pkg/neurelo_sdk`
- Add the dependencies to your `go.mod` file

```bash
mkdir -p ./pkg/neurelo_sdk &&\
unzip neurelo-sdk-golang-cmt_<>.zip -d ./pkg/neurelo_sdk &&\
go get github.com/oapi-codegen/runtime
```

## Usage

-   Make sure to set `NEURELO_API_ENDPOINT` and `NEURELO_API_KEY` env variables before using the client or you can replace them by string in the client file.
-   Create a client file, so that it can be used by other files in the project.

```go
// src/lib/client.go
package lib

import (
  "context"
  "net/http"
  "os"

  neurelo_sdk "github.com/neurelo-public/neurelo-sdk/pkg/neurelo_sdk"
)

var ApiClient *neurelo_sdk.Client

func RequestEditor(ctx context.Context, req *http.Request) error {
  req.Header.Set("X-API-KEY", os.Getenv("NEURELO_API_KEY"))
  return nil
}

// Setup client after reading env variables or in main.go
func SetupApiClient() {
  hc := http.Client{}
  server := os.Getenv("NEURELO_API_ENDPOINT")
  api_client := neurelo_sdk.Client{
    Server: server,
    Client: &hc,
    RequestEditors: []neurelo_sdk.RequestEditorFn{
    RequestEditor,
    },
  }
  ApiClient = &api_client
}
```

## API Usage
-   Then use the client in other files to make API calls.
```go
// main.go
package main

import (
  "context"
  "fmt"

  neurelo_sdk "github.com/neurelo-public/neurelo-sdk/pkg/neurelo_sdk"
  lib "github.com/neurelo-public/neurelo-sdk/src/lib"
)

func Execute() {
  ctx := context.Background()

  take := 10
  skip := 0

  res, err := lib.ApiClient.FindActor(ctx, &neurelo_sdk.FindActorParams{
    Take: &take,
    Skip: &skip,
  })
  if err != nil {
    panic(err)
  }

  parsedRes, err := neurelo_sdk.ParseFindActorResponse(res)
  if err != nil {
    panic(err)
  }

  fmt.Println(string(parsedRes.Body))
}

func main() {
  lib.SetupApiClient()
  Execute()
}
```
- Execute the main file to see the output.
```bash
go run main.go
```

## Setup Environment Variables (Optional):
- Install the `godotenv` package
```bash
go get github.com/joho/godotenv
```
- Create a `.env` file in the root of your project
```bash
touch .env &&\
echo "NEURELO_API_ENDPOINT=<api-endpoint>" >> .env &&\
echo "NEURELO_API_KEY=<api-key>" >> .env
```
- Load the environment variables in the `main.go` file
```go
// main.go
package main

import (
  // other imports ...
  godotenv "github.com/joho/godotenv"
)

func main() {
  godotenv.Load(".env")
  lib.SetupApiClient()
  Execute()
}
```
