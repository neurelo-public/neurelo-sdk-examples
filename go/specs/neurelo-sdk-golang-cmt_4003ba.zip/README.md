# Golang SDK

The generated Neurelo Golang SDK provides easy access to your Neurelo APIs for Golang applications.

# Installation

-   Copy generated sdk `neurelo-sdk-golang-cmt_<>.zip` to your project.
-   Unzip the sdk to `project_root/pkg/neurelo_sdk`
-   Add `pkg` directory to `.gitignore` file.
-   Add `neurelo_sdk` to `go.mod` file by running `go mod edit -replace=github.com/<username>/neurelo-go-sdk=./pkg/neurelo_sdk`
-   Your `go.mod` file should look like this:

```go
module github.com/<username>/<project_name>

go 1.21.3

replace github.com/<username>/neurelo-go-sdk => ./pkg/neurelo_sdk

require (
	github.com/<username>/neurelo-go-sdk v0.0.1
)
```

-   You will also need to add go workspace file by running

```sh
go work init && go work use ./pkg/neurelo_sdk .
```

command (Additionally, you can also add other packages to go workspace file).

## Requirements

-   GO binaries are installed on your system and included in your path.
-   GO package to configure environment variables.

# Usage

-   Create a client file, so that it can be used by other files in the project.

```go
package lib

import (
	"os"
    neurelo_sdk "github.com/smitpatelx/neurelo-go-htmx-example-sdk"
)

var NeureloClient *neurelo_sdk.APIClient

// Setup client after reading env variables or in main.go
func SetupClient() {
	sdk_config := neurelo_sdk.NewConfiguration()
	sdk_config.Host = os.Getenv("NEURELO_API_ENDPOINT")
	sdk_config.DefaultHeader["X-API-KEY"] = os.Getenv("NEURELO_API_KEY")
	sdk_config.Debug = false

	NeureloClient = neurelo_sdk.NewAPIClient(sdk_config)
}
```

## Environment Configuration

-   Make sure to set `NEURELO_API_ENDPOINT` and `NEURELO_API_KEY` env variables before using the client or you can set them in the client file.

## API Usage

-   Then use the client in other files to make API calls.

```go
find_actor := lib.NeureloClient.ActorAPI.FindActor(context.Background()).Take(take).Skip(skip).Filter(filter);

res, _, err := find_actor.Execute()
if err != nil {
    fmt.Println(err)
    return nil
}
```
